"""
MicroPython IoT Weather Station Example for Wokwi.com

To view the data:

1. Go to http://www.hivemq.com/demos/websocket-client/
2. Click "Connect"
3. Under Subscriptions, click "Add New Topic Subscription"
4. In the Topic field, type "wokwi-weather" then click "Subscribe"

Now click on the DHT22 sensor in the simulation,
change the temperature/humidity, and you should see
the message appear on the MQTT Broker, in the "Messages" pane.

Copyright (C) 2022, Uri Shaked

https://wokwi.com/arduino/projects/322577683855704658
"""

"""
Tugas SubCPMK 3 - ESP32 IoT Sensor (Wokwi + MQTT)
Mengirim data suhu, kelembapan, dan kecerahan, serta
menerima perintah untuk pompa/relay via MQTT.

Broker demo: broker.mqttdashboard.com
Topic:
  - Publish data sensor: "esp32/data"
  - Subscribe relay/pompa: "esp32/pump"
"""

import network
import time
from machine import Pin, ADC
import dht
import ujson
from umqtt.simple import MQTTClient

# --- Konfigurasi MQTT ---
MQTT_CLIENT_ID = "f22dc8d6-e5a2-4f10-9dfb-0f943f94e16f"
MQTT_BROKER    = "broker.hivemq.com"
MQTT_USER      = "data_sensor"
MQTT_PASSWORD  = ""
TOPIC_PUB      = "esp32/data"
TOPIC_SUB      = "esp32/pump"

# --- Inisialisasi Sensor ---
dht_sensor = dht.DHT22(Pin(15))
ldr = ADC(Pin(34))  # pin analog untuk simulasi cahaya
ldr.atten(ADC.ATTN_11DB)

# --- Inisialisasi Relay (atau LED) ---
relay = Pin(2, Pin.OUT)
relay.value(0)  # awalnya OFF

# --- WiFi ---
print("Connecting to WiFi", end="")
sta_if = network.WLAN(network.STA_IF)
sta_if.active(True)
sta_if.connect("Wokwi-GUEST", "")
while not sta_if.isconnected():
    print(".", end="")
    time.sleep(0.2)
print(" Connected!")
print("IP:", sta_if.ifconfig()[0])

# --- Callback untuk pesan masuk dari MQTT ---
def sub_cb(topic, msg):
    print("Pesan masuk dari topic:", topic, "->", msg)
    if msg == b"ON":
        relay.value(1)
        print("Relay ON (pompa aktif)")
    elif msg == b"OFF":
        relay.value(0)
        print("Relay OFF (pompa mati)")

# --- Setup MQTT ---
client = MQTTClient(MQTT_CLIENT_ID, MQTT_BROKER,
                    user=MQTT_USER, password=MQTT_PASSWORD)
client.set_callback(sub_cb)
client.connect()
client.subscribe(TOPIC_SUB)
print("Connected ke MQTT broker dan subscribe ke topic", TOPIC_SUB)

prev_data = ""

while True:
    try:
        # Baca sensor
        dht_sensor.measure()
        suhu = dht_sensor.temperature()
        kelembapan = dht_sensor.humidity()
        lux = int(ldr.read() / 40)  # skala simulasi kecerahan

        # Buat payload JSON
        data = {
            "suhu": suhu,
            "humidity": kelembapan,
            "lux": lux,
            "timestamp": time.time()
        }
        msg = ujson.dumps(data)

        # Jika ada perubahan data, kirim ke MQTT
        if msg != prev_data:
            client.publish(TOPIC_PUB, msg)
            print("Publish:", msg)
            prev_data = msg

        # Cek jika ada perintah masuk (pump ON/OFF)
        client.check_msg()

        time.sleep(3)

    except Exception as e:
        print("Error:", e)
        time.sleep(2)
